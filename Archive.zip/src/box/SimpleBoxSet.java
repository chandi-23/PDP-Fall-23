package box;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * This Class implements the methods in BoxSet Interface.
 */
public class SimpleBoxSet implements BoxSet {

  ArrayList<ArrayList<Integer>> boxSet = new ArrayList<>();
  ArrayList<Integer> tempSet = new ArrayList<>();

  @Override
  public void add(int x, int y, int width, int height) throws IllegalArgumentException {
    if (width <0 || height<0){
      throw new IllegalArgumentException("Invalid Width/Height provided");
    }
    System.out.println("\nAdding box");

    for (int i =0; i < boxSet.size(); i++){
      System.out.println("\nChecking for values " +boxSet.get(i).get(0) +" " + boxSet.get(i).get(1));

      if (isOverlapping(i, x, y, width, height)) {

        System.out.println("above coordinates are overlapping\n");
        //findIntersection(i, x, y, width, height);
        ArrayList<Integer> intersection = calculateCommonArea(i, x, y, width, height);
          System.out.println("Intersection coordinates: " + intersection.get(0) +
                  ", " + intersection.get(1) +
                  ", " + intersection.get(2) +
                  ", " + intersection.get(3));

          makeNewFigure(i, intersection.get(0), intersection.get(1), intersection.get(2), intersection.get(3));
      }
    }

    for(int i =tempSet.size()-1; i>-1;i--){

      int indexToRemove = tempSet.get(i);

      // Check if the index is valid
      if (indexToRemove >= 0 && indexToRemove < boxSet.size()) {
        boxSet.remove(indexToRemove);
      }
    }
    tempSet= new ArrayList<>();

    ArrayList<Integer> newRect = new ArrayList<>(Arrays.asList(x, y, width, height));
    boxSet.add(newRect);

    int i =0;
    while (i<boxSet.size()){
      System.out.println(boxSet.get(i));
      i++;
    }
    System.out.println("---------------------");

  }

  @Override
  public void subtract(int x, int y, int width, int height) throws IllegalArgumentException {
    if (width <0 || height<0){
      throw new IllegalArgumentException("Invalid Width/Height provided");
    }
    System.out.println("\nSubtracting box");
    for (int i =0; i < boxSet.size(); i++){
      if (isOverlapping(i, x, y, width, height)) {
        System.out.println("Rectangles are overlapping");
        //findIntersection(i, x, y, width, height);
        ArrayList<Integer> intersection = calculateCommonArea(i, x, y, width, height);
        System.out.println("Intersection coordinates: " + intersection.get(0) +
                ", " + intersection.get(1) +
                ", " + intersection.get(2) +
                ", " + intersection.get(3));

        makeNewFigure(i, intersection.get(0), intersection.get(1), intersection.get(2), intersection.get(3));
      }
    }
    for(int i =tempSet.size()-1; i>-1;i--){

      int indexToRemove = tempSet.get(i);

      // Check if the index is valid
      if (indexToRemove >= 0 && indexToRemove < boxSet.size()) {
        boxSet.remove(indexToRemove);
      }
    }
    tempSet= new ArrayList<>();

    int i =0;
    while (i<boxSet.size()){
      System.out.println(boxSet.get(i));
      i++;
    }
  }

  @Override
  public int[][] getBoxes() {
    int[][] boxesArray = new int[boxSet.size()][4];

    for (int i = 0; i < boxSet.size(); i++) {
      ArrayList<Integer> box = boxSet.get(i);
      boxesArray[i][0] = box.get(0);  // x
      boxesArray[i][1] = box.get(1);  // y
      boxesArray[i][2] = box.get(2);  // width
      boxesArray[i][3] = box.get(3);  // height
    }

    return boxesArray;
  }

  @Override
  public int size() {
    return boxSet.size();
  }

  private boolean isOverlapping(int i, int x, int y, int width, int height){
    // Check for x overlap
    boolean xOvp = (boxSet.get(i).get(0) < x + width) && (x < boxSet.get(i).get(0) + boxSet.get(i).get(2));

    // Check if the y overlap
    boolean yOvp = (boxSet.get(i).get(1) < y + height) && (y < boxSet.get(i).get(1) + boxSet.get(i).get(3));

    // The rectangles overlap if and only if both x and y projections overlap
    return xOvp && yOvp;
  }

  private ArrayList<Integer> calculateCommonArea(int i, int x2, int y2, int width2, int height2) {
    int x1 = boxSet.get(i).get(0);
    int y1 = boxSet.get(i).get(1);
    int width1 = boxSet.get(i).get(2);
    int height1 = boxSet.get(i).get(3);

    // Calculate the coordinates of the overlapping rectangle
    int xOverlap = Math.max(x1, x2);
    int yOverlap = Math.max(y1, y2);
    int xEndOverlap = Math.min(x1 + width1, x2 + width2);
    int yEndOverlap = Math.min(y1 + height1, y2 + height2);

    return new ArrayList<>(Arrays.asList(xOverlap, yOverlap, xEndOverlap, yEndOverlap));

  }

  private void makeNewFigure(int i, int x, int y, int x4, int y4){
    //Cut Vertically first
    // four conditions
    int newX, newY, newWidth, newHeight;

    //Left bottom of common area
    newX = boxSet.get(i).get(0);
    newY = boxSet.get(i).get(1);
    newWidth = x - newX;

    if (newWidth >0){
      newHeight = boxSet.get(i).get(3);
      //Add the box
      System.out.println("1.new box is on the Middle left" + newX + " "+newY);
      boxSet.add(new ArrayList<>(Arrays.asList(newX, newY, newWidth, newHeight)));
    }
    else{

      newHeight =  y - boxSet.get(i).get(1);
      if(newHeight > 0) {
        System.out.println("new box is on the Middle left" + newX + " "+newY);
        newWidth = x4 - newX;
        //Add the box
        System.out.println("2.new box is on the Middle left" + newX + " "+newY);
        boxSet.add(new ArrayList<>(Arrays.asList(newX, newY, newWidth, newHeight)));
      }
    }

  //Right bottom of common Area
  if (boxSet.get(i).get(0) + boxSet.get(i).get(2) == x4 && (boxSet.get(i).get(0) != x) ) {
    //only one box exists
    System.out.println("only one box at the bottom right");
    newHeight = y - boxSet.get(i).get(1);
    if (newHeight >0) {
      newX = x; //from common area
      newY = boxSet.get(i).get(1);
      newWidth = x4 -x;
      //Add the box
      System.out.println("3.Adding box right bottom" + newX + " "+newY);
      boxSet.add(new ArrayList<>(Arrays.asList(newX, newY, newWidth, newHeight)));
    }
  }
  else if (boxSet.get(i).get(0) + boxSet.get(i).get(2) > x4){
    // might have to add 2 boxes
    //middle bottom
    System.out.println("Might have 2 boxes");
    if (boxSet.get(i).get(0) < x && (y - boxSet.get(i).get(1) > 0) ) {
        newX = x;
        newY = boxSet.get(i).get(1);
        newWidth = x4-x;
        newHeight = y - boxSet.get(i).get(1);
      //Add the box
      boxSet.add(new ArrayList<>(Arrays.asList(newX, newY, newWidth, newHeight)));
      System.out.println("4.Added bottom middle box" + newX+" " +newY);
    }

    //right bottom
    newX = x4;
    newY = boxSet.get(i).get(1);
    newWidth = boxSet.get(i).get(0) + boxSet.get(i).get(2) - x4;
    newHeight = boxSet.get(i).get(3);
    //Add the box
    boxSet.add(new ArrayList<>(Arrays.asList(newX, newY, newWidth, newHeight)));
    System.out.println("5.Added bottom Right"+ newX + " "+newY);
    }

  //Top Left
    //System.out.println("on the left middle checking top" +x+ " "+boxSet.get(i).get(0));
  if(x == boxSet.get(i).get(0)) {
    System.out.println("6.0 on the left middle checking top");
    if (boxSet.get(i).get(1) + boxSet.get(i).get(3) > y4){
      newX = x;
      newY = y4;
      newHeight = boxSet.get(i).get(1) + boxSet.get(i).get(3) - y4;
      newWidth = x4 - x;
      //Add the box
      boxSet.add(new ArrayList<>(Arrays.asList(newX, newY, newWidth, newHeight)));
      System.out.println("6.1 new box is on the Middle left" + newX + " "+newY);
    }
    }
  else{
    //else can be clubbed
    //top middle
    if(x > boxSet.get(i).get(0)  && x4 < boxSet.get(i).get(0) + boxSet.get(i).get(2)) {
      newX = x;
      newY = y4;
      newWidth = x4 -x;
      newHeight = boxSet.get(i).get(1) + boxSet.get(i).get(3) - y4;
      if (newHeight>0){
        //Add the box
        System.out.println("7.new box is on the Middle left" + newX + " "+newY);
        boxSet.add(new ArrayList<>(Arrays.asList(newX, newY, newWidth, newHeight)));
      }
    }

    //top right
    else if (x > boxSet.get(i).get(0)  && x4 == boxSet.get(i).get(0) + boxSet.get(i).get(2)){
      newX = x;
      newY = y4;
      newWidth = x4 - x;
      newHeight = boxSet.get(i).get(1) + boxSet.get(i).get(3) - y4;
      if (newHeight>0){
        //Add the box
        System.out.println("8.new box is on the Middle left" + newX + " "+newY);
        boxSet.add(new ArrayList<>(Arrays.asList(newX, newY, newWidth, newHeight)));
      }
    }

  }
    tempSet.add(i);
  }

}
